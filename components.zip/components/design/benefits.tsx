export const GradientLight = () => (
  <div className="pointer-events-none absolute left-1/4 top-0 aspect-square w-full bg-radial-gradient from-[#28206C] to-[#28206C]/0 to-70%" />
);
