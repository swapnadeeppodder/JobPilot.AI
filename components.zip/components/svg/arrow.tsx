"use client";

import React from "react";

type Props = {
  className?: string;
};

const Arrow = ({ className }: Props) => {
  return (
    <svg
      className={className}
      width="16"
      height="16"
      viewBox="0 0 16 16"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M12.172 7L6.808 1.636L8.222 0.222L16 8L8.222 15.778L6.808 14.364L12.172 9H0V7H12.172Z"
        fill="currentColor"
      />
    </svg>
  );
};

export default Arrow;
