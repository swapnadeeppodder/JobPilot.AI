"use client";

import React from "react";
import { cn } from "@/lib/utils";
import TagLine from "./tag-line";

type Props = {
  className?: string;
  title?: string;
  text?: string;
  tag?: string;
};

const Heading = ({ className, title, text, tag }: Props) => {
  return (
    <div className={cn(className, "max-w-[50rem] mx-auto mb-12 lg:mb-20 md:text-center")}>
      {tag && <TagLine className="mb-4 md:justify-center">{tag}</TagLine>}
      {title && <h2 className="h2">{title}</h2>}
      {text && <p className="body-2 mt-4 text-n-4">{text}</p>}
    </div>
  );
};

export default Heading;
